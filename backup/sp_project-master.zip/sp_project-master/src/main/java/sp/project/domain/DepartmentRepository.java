package sp.project.domain;

import java.util.List;
import org.springframework.data.repository.CrudRepository;

public interface DepartmentRepository extends CrudRepository<Department, Long> {
	
	Department findById(long id);
	Department findByName(String name);
}