package sp.project.domain;

import java.util.List;
import org.springframework.data.repository.CrudRepository;

public interface EmployeeRepository extends CrudRepository<Employee, Long> {
	
	Employee findById(long id);
	List<Employee> findByDepartmentId(long departmentId);
	List<Employee> findByPosition(String position);
}