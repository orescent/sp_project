package sp.project.web;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import sp.project.domain.Department;
import sp.project.domain.DepartmentRepository;
import sp.project.domain.Employee;
import sp.project.domain.EmployeeRepository;

@Controller
public class ProjectController {
	
	@Autowired
	private EmployeeRepository erepository;
	@Autowired
	private DepartmentRepository drepository;
	
	@RequestMapping(value="/login")
    public String login() {	
        return "login";
    }
	
	@RequestMapping("/index")
	public String hello(Model model) {
		return null;
	}
	
	@RequestMapping("/employeelist")
	public String employeeList(Model model) {
		model.addAttribute("employees", erepository.findAll());
		model.addAttribute("departments", drepository.findAll());
		return "employeelist";
	}
	
	@RequestMapping(value="/employees", method=RequestMethod.GET)
	public @ResponseBody Iterable<Employee> employeeListRest() {
		return erepository.findAll();
	}

	@RequestMapping(value="/employee/{id}", method=RequestMethod.GET)
	public @ResponseBody Optional<Employee> findEmployeeRest(@PathVariable("id") Long employeeId) {
		return erepository.findById(employeeId);
	}
	
	@RequestMapping(value="/addemployee")
	public String addEmployee(Model model) {
		model.addAttribute("employee", new Employee());
		model.addAttribute("departments", drepository.findAll());
		return "addemployee";
	}
	
	@RequestMapping(value="/addemployee/{department}")
	public String addEmployee(@PathVariable("department") String departmentName, Model model) {
		Department currentDepartment = drepository.findByName(departmentName);
		model.addAttribute("employee", new Employee(currentDepartment));
		model.addAttribute("departments", drepository.findAll());
		return "addemployee";
	}
	
	@RequestMapping(value="/saveemployee", method=RequestMethod.POST)
	public String save(Employee employee) {
		if (employee.getBirthdate() == "") {
			employee.setBirthdate(null);
		}
		erepository.save(employee);
		return "redirect:employeelist";
	}
	
	@RequestMapping(value="/saveandadd", method=RequestMethod.POST)
	public String saveandadd(Employee employee) {
		if (employee.getBirthdate() == "") {
			employee.setBirthdate(null);
		}
		erepository.save(employee);
		return "redirect:adddepartment";
	}
	
	@RequestMapping(value="/cancel", method=RequestMethod.POST)
	public String cancel(Employee employee) {
		//erepository.save(employee);
		return "redirect:employeelist";
	}
	
	@RequestMapping("/departmentlist")
	public String departmentList(Model model) {
		model.addAttribute("employees", erepository.findAll());
		model.addAttribute("departments", drepository.findAll());
		return "departmentlist";
	}
	
	@PreAuthorize("hasAuthority('ADMIN')")
	@RequestMapping(value="/deleteemployee/{id}")
	public String deleteEmployee(@PathVariable("id") Long employeeId, Model model){
		erepository.deleteById(employeeId);
		return "redirect:../employeelist";
	}
	
	@RequestMapping(value="/editemployee/{id}")
	public String editEmployee(@PathVariable("id") Long employeeId, Model model){
		Optional<Employee> currentEmployee = erepository.findById(employeeId);
		model.addAttribute("employee", currentEmployee);
		model.addAttribute("departments", drepository.findAll());
		return "editemployee";
	}
	
	@RequestMapping(value="/departmentview/{id}")
	public String departmentView(@PathVariable("id") Long departmentId, Model model){
		Optional<Department> currentDepartment = drepository.findById(departmentId);
		model.addAttribute("department", currentDepartment);
		model.addAttribute("employees", erepository.findByDepartmentId(departmentId));
		String director = "";
		List<Employee> employees = erepository.findByDepartmentId(departmentId);
		for (Employee employee : employees) {
			if (employee.getPosition() == "Director") {
				director = employee.getName();
			}
		}
		if (director == "") {
			director = "None";
		}
		model.addAttribute("director", director);
		return "departmentview";
	}
	
}