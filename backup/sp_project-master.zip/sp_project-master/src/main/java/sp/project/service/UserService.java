package sp.project.service;

import org.springframework.security.core.userdetails.UserDetailsService;

import sp.project.model.User;
import sp.project.web.dto.UserRegistrationDto;

public interface UserService extends UserDetailsService {

	User findByUsername(String username);
    User findByEmail(String email);

    User save(UserRegistrationDto registration);

    void updatePassword(String password, Long userId);
}